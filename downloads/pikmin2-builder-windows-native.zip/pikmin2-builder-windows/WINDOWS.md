# Windows native build tools — no Docker required

Extract the **entire ZIP** to a writable local folder and double-click
`pikmin2-builder.exe`. Supported host: Windows 10/11 x64.
Python, Windows Ninja and Windows makerom are included. You do not need Docker,
WSL, devkitPro or a separate Python installation for the supplied workflows.

The launcher offers two builds:

- **YES — GameCube source build:** uses the exact uploaded `pikmin2-main.zip`
  source under `decomp/pikmin2-main`. Extracts the original main.dol, checks its
  SHA-1 against the supplied region config, then runs the source's configure.py
  and Ninja **natively on Windows**. The original build scripts download their
  configured compilers/tools on first use, so Internet access is required.
  Output: `decomp/pikmin2-main/build/GPVE01/main.dol` (region varies).
  This is a **GameCube executable**, not a 3DS port.
- **NO — 3DS banner preview:** extracts the ROM banner and packages it with a
  bundled precompiled ARM viewer using native Windows makerom. Output:
  `app/pikmin2-preview.cia`. No compiler download or Docker setup is required.
  This option does not compile or execute the decompilation's game engine.

**A playable Pikmin 2 3DS port is not implemented.** See PORTING.md.

## PowerShell commands

```powershell
# Original source -> GameCube executable
.\pikmin2-builder.exe "C:\Games\Pikmin 2.iso" --gamecube

# ROM banner -> native 3DS preview CIA, no gameplay
.\pikmin2-builder.exe "C:\Games\Pikmin 2.iso"

# Generated test artwork -> preview CIA, no ROM or Internet needed
.\pikmin2-builder.exe --demo
```

Keep all supplied folders together. Replace the entire old Docker-based bundle
with this new extraction. Do not copy only the EXE out of the folder.

Supported discs: uncompressed retail GameCube ISO/GCM with IDs GPVE01, GPVP01,
GPVJ01. The source build requires the exact DOL checksum in its supplied config.
Unsupported revisions are rejected without altering expected checksums.
No game ROM is included. The default artwork is a generated gradient.

## Verification and limits

- Actual Windows EXE, bundled Windows Python and native Windows makerom executed
  under Wine to produce a CIA, without invoking Docker from the application.
- The resulting CIA contains the expected test texture; ctrtool confirms content,
  ExeFS and RomFS hashes. Homebrew ticket/TMD/access-descriptor signatures are not
  official Nintendo signatures and fail retail signature checks as expected.
- Windows Ninja starts; the uploaded configure.py runs with bundled Windows Python.
- Thirteen synthetic-data parser/extraction tests pass.
- All 2,151 uploaded source files remain byte-for-byte unchanged; manifest under
  `validation/uploaded-source-sha256.json`.
- Not tested on a physical Windows PC or 3DS. A complete real-ROM source build
  remains untested because no matching ROM was supplied. GUI dialogs were not
  exercised under headless Wine.

The preview's precompiled ELF, SMDH and HOME Menu banner are included under app/.
Changing the viewer's C source requires rebuilding its ARM ELF with devkitARM;
normal ROM-to-preview packaging does not. This Windows workflow produces a CIA,
not a newly compiled 3DSX.

## Provenance and rebuild

- CPython 3.12.10: official NuGet Windows runtime; license in runtime/LICENSE.txt.
- Ninja 1.12.1: official ninja-build/ninja Windows release.
- makerom: Project_CTR commit d52c2b0e788c2d085763d7c5dcc4b2edd9ffb7d8, cross-compiled
  with MinGW-w64 using PROJECT_PLATFORM=WIN32 and static runtime linking.
- Other notices: THIRD_PARTY_LICENSES/. Build scripts and launcher C source included.

Launcher rebuild with MinGW-w64:

```sh
x86_64-w64-mingw32-gcc -O2 -municode -static windows/launcher.c \
  -o pikmin2-builder.exe -lcomdlg32 -lshell32
```
