#!/usr/bin/env python3
"""Build the supplied GameCube decompilation or a 3DS asset viewer. No 3DS gameplay port."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys

from preview import prepare
from decomp_build import prepare_decomp

IMAGE = 'devkitpro/devkitarm@sha256:116afba8df8453961de2936ffab20dd441edf4d682856c1ec8b0e53d7ed0bbf5'
ROOT = Path(sys.executable).resolve().parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent


def docker_run(command):
    # Windows uses Docker Desktop's selected Linux-container context.
    environment = os.environ.copy()
    docker = ['docker']
    if sys.platform != 'win32':
        for name in ('DOCKER_HOST', 'DOCKER_CONTEXT', 'DOCKER_TLS', 'DOCKER_TLS_VERIFY', 'DOCKER_CERT_PATH'):
            environment.pop(name, None)
        docker.append('--host=unix:///var/run/docker.sock')
    subprocess.run(docker + ['run', '--rm', '--mount', f'type=bind,src={ROOT},dst=/project',
                            '-w', '/project', IMAGE] + command, env=environment, check=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('rom', nargs='?', type=Path, help='Uncompressed retail GameCube ISO/GCM')
    parser.add_argument('--demo', action='store_true', help='Use a generated test pattern, no game data')
    parser.add_argument('--docker', action='store_true',
                        help='Optional Linux-container build; Windows builds run natively by default')
    parser.add_argument('--gamecube', action='store_true',
                        help='Compile the supplied decompilation to GameCube main.dol, NOT a 3DS game')
    parser.add_argument('--extract-only', action='store_true')
    parser.add_argument('--makerom', default=shutil.which('makerom') or str(ROOT / 'tools/makerom'))
    parser.add_argument('--bannertool', default=shutil.which('bannertool') or str(ROOT / 'tools/bannertool'))
    args = parser.parse_args()
    if bool(args.rom) == args.demo:
        parser.error('Provide a ROM path OR --demo')
    app = ROOT / 'app'
    assets = app / 'romfs'
    if not (app / 'Makefile').is_file():
        parser.error('Keep this executable beside the supplied app/ directory')
    try:
        if args.gamecube:
            if args.demo:
                raise ValueError('The decompilation requires a real matching game ROM; demo is preview-only')
            source = ROOT / 'decomp' / 'pikmin2-main'
            version = prepare_decomp(args.rom, source)
            print(f'Compiling uploaded decompilation for {version}: GameCube DOL output, not CIA.', flush=True)
            if args.docker:
                docker_run(['sh', '-c',
                            'chmod +x /project/tools/container/ninja; export PATH=/project/tools/container:$PATH; '
                            f'cd /project/decomp/pikmin2-main && python3 configure.py --version {version} && ninja -j2'])
            else:
                environment = os.environ.copy()
                environment['PATH'] = os.pathsep.join([str(ROOT / 'tools/windows'),
                                                       str(ROOT / 'runtime'), environment.get('PATH', '')])
                subprocess.run([sys.executable, 'configure.py', '--version', version],
                               cwd=source, env=environment, check=True)
                ninja = str(ROOT / 'tools/windows/ninja.exe') if sys.platform == 'win32' else 'ninja'
                subprocess.run([ninja, '-j2'], cwd=source, env=environment, check=True)
            print(f'GameCube output: {source / "build" / version / "main.dol"}')
            return
        if args.demo:
            assets.mkdir(exist_ok=True)
            (assets / 'banner.rgb').write_bytes(bytes(
                value for y in range(32) for x in range(96)
                for value in (x * 255 // 95, y * 255 // 31, 96)))
            (assets / 'disc.txt').write_text('SYNTHETIC TEST PATTERN\n')
            for name in ('manifest.json', 'banner.ppm'):
                (assets / name).unlink(missing_ok=True)
        else:
            prepare(args.rom, assets)
        if args.extract_only:
            print(f'Assets written to {assets}. No gameplay has been ported.')
            return
        if args.docker:
            docker_run(['sh', '/project/tools/container/build-preview.sh'])
            print(f'Created {app / "pikmin2-preview.cia"}')
            print('ASSET PREVIEW ONLY. This CIA does not contain playable Pikmin 2.')
            return
        if sys.platform == 'win32':
            # This viewer's ARM code is invariant. Package its precompiled ELF
            # with the user's extracted RomFS, using a native Windows packager.
            makerom = ROOT / 'tools/windows/makerom.exe'
            for resource in (makerom, app / 'pikmin2-preview.elf',
                             app / 'pikmin2-preview.smdh', app / 'menu.bnr'):
                if not resource.is_file():
                    raise ValueError(f'Missing bundled resource: {resource}. Extract the entire ZIP.')
            subprocess.run([str(makerom), '-f', 'cia', '-o', 'pikmin2-preview.cia',
                            '-rsf', 'preview.rsf', '-target', 't', '-elf', 'pikmin2-preview.elf',
                            '-icon', 'pikmin2-preview.smdh', '-banner', 'menu.bnr',
                            '-desc', 'app:4'], cwd=app, check=True)
            print(f'Created {app / "pikmin2-preview.cia"} without Docker.')
            print('ASSET PREVIEW ONLY. This CIA does not contain playable Pikmin 2.')
            return
        makerom = str(Path(args.makerom).resolve())
        if not Path(makerom).is_file():
            raise ValueError('makerom not found; install it and pass --makerom PATH')
        bannertool = str(Path(args.bannertool).resolve())
        if not Path(bannertool).is_file():
            raise ValueError('bannertool not found; install it and pass --bannertool PATH')
        subprocess.run(['make', '-j2'], cwd=app, check=True)
        subprocess.run([bannertool, 'makebanner', '-i', 'assets/menu.png',
                        '-a', 'assets/silence.wav', '-o', 'menu.bnr'], cwd=app, check=True)
        subprocess.run([makerom, '-f', 'cia', '-o', 'pikmin2-preview.cia',
                        '-rsf', 'preview.rsf', '-target', 't', '-elf', 'pikmin2-preview.elf',
                        '-icon', 'pikmin2-preview.smdh', '-banner', 'menu.bnr',
                        '-desc', 'app:4'], cwd=app, check=True)
        print(f'Created {app / "pikmin2-preview.cia"}')
        print('ASSET PREVIEW ONLY. This CIA does not contain playable Pikmin 2.')
    except (OSError, ValueError, subprocess.CalledProcessError) as exc:
        parser.exit(1, f'Build failed: {exc}\n')


if __name__ == '__main__':
    main()
