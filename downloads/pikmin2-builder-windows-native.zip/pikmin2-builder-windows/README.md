# Pikmin 2 → 3DS investigation and asset preview

**Windows native bundle (no Docker required):** see [WINDOWS.md](WINDOWS.md). It includes a real Windows
launcher, bundled Python, and your uploaded decompilation unchanged. Its
`--gamecube` mode compiles that source to a GameCube DOL. The separate preview
CIA mode still does not compile the game engine for 3DS.

**This is not a playable Pikmin 2 port or a full-game ROM converter.**

This first prototype reads `opening.bnr` from a retail Pikmin 2 GameCube ISO,
decodes its tiled RGB5A3 image, and embeds the decoded banner in a small native
3DS application. The application displays that image on its top screen.
Game logic, levels, characters, sound, and controller behavior are not ported.

## What was actually verified

- Thirteen extractor/decoder and DOL-preparation tests pass, using synthetic data (no game assets).
- The viewer compiles with devkitARM/libctru to ARM ELF and `.3dsx`.
- makerom produces an unencrypted homebrew `.cia`, with icon and HOME Menu banner.
- The generated CIA contains the expected synthetic texture and label; its
  ExeFS header hash matches, and the ELF machine type is ARM.
- Independent ctrtool inspection confirms content, ExeFS, RomFS and section
  hashes. It reports invalid ticket/TMD/access-descriptor signatures, expected
  for this homebrew package; this is not an official Nintendo-signed title.
- The command-line builder runs through the complete build with `--demo`.

There has been **no emulator or physical 3DS execution**, and no real ROM was
supplied for extraction testing. Compilation and package checks do not establish
that the app launches or displays correctly. The included demo uses a generated
gradient and contains no game data. It should show a gradient on the upper screen
and a clear preview-only message below; START should exit.

## Linux executable bundle

Extract the entire bundle. Keep `pikmin2-preview-builder`, `app/`, and `tools/`
together. The executable is Linux x86-64, built in this environment; it is not a
Windows `.exe`. It still requires Docker and access to the official devkitPro
image to compile 3DS code. The included makerom and bannertool are Linux binaries.

```sh
chmod +x pikmin2-preview-builder tools/makerom tools/bannertool
./pikmin2-preview-builder --demo --docker
./pikmin2-preview-builder "/path/to/your/Pikmin 2.iso" --docker
```

Output: `app/pikmin2-preview.cia` and `app/pikmin2-preview.3dsx`.
Both are **asset-viewer applications only**. For runtime testing, use a 3DS
configured to run homebrew; the `.3dsx` can be tested in Homebrew Launcher.
The CIA's prototype UniqueId is `0xF2A71` (see `app/preview.rsf`).
The full package inspection is recorded in `validation/cia-inspection.txt`;
signature failures are not counted as passed checks.

Only uncompressed retail GameCube ISO/GCM images with IDs `GPVE01`, `GPVP01`, or
`GPVJ01` are accepted. RVZ, NKit, Wii images and demos are unsupported. The utility
does not download games, alter the input ROM, or include copyrighted assets.
Running it again replaces its generated preview assets in `app/romfs/`.

## Build from source

Python 3.9+ is sufficient for extraction and tests:

```sh
python3 -m unittest discover -s tests -v
python3 preview.py "/path/to/Pikmin 2.iso"
```

Use devkitPro's devkitARM and libctru, GNU make, makerom, and bannertool for a
native build. With these on PATH and DEVKITARM/DEVKITPRO activated:

```sh
python3 build_preview.py "/path/to/Pikmin 2.iso"
```

Or use Docker for the ARM compiler and host binaries for packaging:

```sh
python3 build_preview.py --demo --docker \
  --makerom /path/to/makerom --bannertool /path/to/bannertool
```

The Docker image is pinned in `build_preview.py`. In a managed cloud environment,
retain its Docker proxy configuration and CA trust. The build container itself
does not download dependencies. Use the existing checkout; cloud tasks are
already isolated and do not need a separate Git worktree.

To create the desktop executable on the desired host OS:

```sh
python3 -m pip install pyinstaller==6.22.3
pyinstaller --onefile --name pikmin2-preview-builder build_preview.py
```

Place the resulting executable beside `app/`. Supply makerom and bannertool for
that OS under `tools/`, or pass their paths explicitly. Windows builds require
testing on Windows; the Linux executable cannot be renamed to `.exe`.

## What remains for a real port

See [PORTING.md](PORTING.md). There is no implemented game-engine compatibility
layer. A CIA is a package around an already runnable 3DS program; it does not
translate GameCube machine code or hardware commands.

## Tool provenance

- devkitPro image: `devkitpro/devkitarm@sha256:116afba8df8453961de2936ffab20dd441edf4d682856c1ec8b0e53d7ed0bbf5`
- makerom: <https://github.com/3DSGuy/Project_CTR>, commit
  `d52c2b0e788c2d085763d7c5dcc4b2edd9ffb7d8`.
  Built with `make deps -j4` then `make -j4` in `makerom/`.
- bannertool: <https://github.com/carstene1ns/3ds-bannertool>, commit
  `734d33be79fd3f8c29c6296158f06ac7c5ca9dcb`.
  Its C++17 sources and bundled codec sources were compiled with g++.
- `app/Makefile` is adapted from devkitPro's official 3ds-examples application
  template: <https://github.com/devkitPro/3ds-examples>.

The original uploaded decompilation is included unchanged in the Windows bundle
under `decomp/pikmin2-main`. Its separate `--gamecube` workflow builds GameCube
code. The preview CIA does not execute code from that decompilation.
