#include <3ds.h>
#include <stdio.h>
#include <string.h>

/* Native 3DS proof of asset decoding; no GameCube code or emulation. */
static unsigned char banner[96 * 32 * 3];

static void draw_banner(void)
{
    u16 width, height;
    u8 *fb = gfxGetFramebuffer(GFX_TOP, GFX_LEFT, &width, &height);
    memset(fb, 0, (size_t)width * height * 3);
    for (int y = 0; y < 32; ++y)
        for (int x = 0; x < 96; ++x)
            for (int dy = 0; dy < 3; ++dy)
                for (int dx = 0; dx < 3; ++dx) {
                    int sx = 56 + x * 3 + dx;
                    int sy = 72 + y * 3 + dy;
                    size_t dst = ((size_t)sx * 240 + 239 - sy) * 3;
                    size_t src = ((size_t)y * 96 + x) * 3;
                    fb[dst] = banner[src + 2];
                    fb[dst + 1] = banner[src + 1];
                    fb[dst + 2] = banner[src];
                }
}

int main(void)
{
    gfxInitDefault();
    gfxSetDoubleBuffering(GFX_TOP, false);
    gfxSetDoubleBuffering(GFX_BOTTOM, false);
    consoleInit(GFX_BOTTOM, NULL);
    printf("Pikmin 2: asset preview\n\n");
    Result result = romfsInit();
    bool loaded = false;
    if (R_SUCCEEDED(result)) {
        FILE *f = fopen("romfs:/banner.rgb", "rb");
        if (f) {
            loaded = fread(banner, 1, sizeof(banner), f) == sizeof(banner);
            loaded = loaded && fgetc(f) == EOF;
            fclose(f);
        }
    }
    if (loaded) {
        draw_banner();
        printf("Preview texture loaded.\n");
        FILE *f = fopen("romfs:/disc.txt", "r");
        if (f) {
            char label[64] = {0};
            if (fgets(label, sizeof(label), f)) printf("Source: %s\n", label);
            fclose(f);
        }
    } else {
        printf("No valid banner.rgb in RomFS.\nRun preview.py with your ISO, then rebuild.\n");
    }
    printf("\nThis is NOT the playable game.\nGameplay and engine port are unfinished.\n\nSTART: exit\n");
    while (aptMainLoop()) {
        hidScanInput();
        if (hidKeysDown() & KEY_START) break;
        gfxFlushBuffers();
        gspWaitForVBlank();
    }
    if (R_SUCCEEDED(result)) romfsExit();
    gfxExit();
    return 0;
}
