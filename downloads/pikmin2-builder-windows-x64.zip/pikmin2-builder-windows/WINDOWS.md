# Windows build tools — read before running

Extract the **entire ZIP** to a writable local folder, then double-click
`pikmin2-builder.exe`. Do not run it directly from inside the ZIP.

Supported host: Windows 10/11 x64. Python 3.12.10 is included; no separate Python
installation is required. Builds require Docker Desktop installed, running,
and using **Linux containers**. Allow Docker Desktop to access the extracted
folder. The first build downloads the pinned devkitPro image (several GB on disk).
The GameCube build additionally downloads the decompilation's configured tools.

The launcher offers two different builds:

- **YES: GameCube source build.** Uses the exact `pikmin2-main.zip` source you
  supplied, included under `decomp/pikmin2-main/`. It extracts `main.dol` from
  your retail GameCube ISO, checks its SHA-1 against that source's region config,
  and invokes the source's original `configure.py` and Ninja build. Output:
  `decomp/pikmin2-main/build/GPVE01/main.dol` (region varies). This is a
  **GameCube executable**, not a 3DS port or CIA.
- **NO: 3DS asset-preview build.** Extracts only the disc banner and builds a
  small native viewer. Output: `app/pikmin2-preview.cia` and `.3dsx`.
  **It does not compile or execute the game engine from the supplied source.**

There is no full-game 3DS compiler in this bundle. The supplied game code still
needs the substantial port described in `PORTING.md`. Packaging a DOL as a CIA
would not make it work on a 3DS.

## Command-line usage (PowerShell)

```powershell
# Original uploaded source -> GameCube executable
.\pikmin2-builder.exe "C:\Games\Pikmin 2.iso" --gamecube

# ROM banner -> 3DS preview CIA, no gameplay
.\pikmin2-builder.exe "C:\Games\Pikmin 2.iso"

# Generated test artwork -> 3DS preview CIA, no ROM needed
.\pikmin2-builder.exe --demo

# Extract assets only, without Docker
.\pikmin2-builder.exe "C:\Games\Pikmin 2.iso" --extract-only
```

Supported discs: uncompressed retail GameCube ISO/GCM, IDs GPVE01, GPVP01, GPVJ01.
The source build requires the exact executable checksum in its supplied config;
an unsupported revision is rejected without changing expected checksums.
No game ROM or Nintendo game assets are included. `app/romfs/` initially contains
a generated demo gradient.

## What was tested

- Real x64 Windows PE launcher compiled with MinGW-w64; not a renamed Linux binary.
- Launcher and bundled Windows Python smoke-tested under Wine: help, synthetic-ROM
  extraction (including a path with spaces), and source checksum rejection.
- Thirteen parser/extraction tests pass using synthetic data.
- Container-compatible packagers rebuilt and full preview-CIA build passed using
  the same pinned Linux container used by Docker Desktop.
- All **2,151 uploaded source files** preserved byte-for-byte. SHA-256 manifest:
  `validation/uploaded-source-sha256.json`.
- Uploaded decompilation's configuration help runs successfully.

Not tested: interactive Windows file dialogs, Docker Desktop on a physical
Windows PC, a complete real-ROM decompilation build, or 3DS execution. No real
ROM was provided. Wine smoke tests are not full Windows or hardware validation.
The generated CIA is homebrew, not Nintendo-signed.

## Rebuild the launcher

The launcher source is `windows/launcher.c`. Build with MinGW-w64:

```sh
x86_64-w64-mingw32-gcc -O2 -municode -static windows/launcher.c \
  -o pikmin2-builder.exe -lcomdlg32 -lshell32
```

The runtime is the official Python 3.12.10 NuGet package from
<https://www.nuget.org/packages/python/3.12.10>; its license is in
`runtime/LICENSE.txt`. Launcher source and both Python build scripts are included.
Third-party packaging-tool licenses are under `THIRD_PARTY_LICENSES/`.
