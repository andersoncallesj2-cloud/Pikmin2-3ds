# Findings from the uploaded source

The upload is projectPiki's work-in-progress GameCube decompilation, not an
existing 3DS engine. Its documented output is `build/GPVE01/main.dol`.

Concrete obstacles:

1. `configure.py` selects Gekko/PowerPC instructions and Metrowerks GC compilers.
   A successful original build would still target GameCube hardware.
2. `include/Dolphin/GX/GXFifo.h` uses the GameCube graphics FIFO at `0xCC008000`.
   Those writes must become actual PICA200 rendering operations, with shader,
   texture, TEV, lighting and display-list translation. Empty GX stubs would
   hide the problem and produce no usable game graphics.
3. `src/Dolphin/os/OSContext.c` contains PowerPC context/FPU code under compiler
   conditionals. Compiling the non-Metrowerks branch does not provide an ARM
   scheduler or preserve GameCube execution semantics.
4. JKernel/JSystem depend on GameCube heaps, threads, DVD access, ARAM, graphics,
   audio and other platform services. These need real implementations or
   replacements using libctru and the 3DS graphics/audio libraries.
5. Native data access assumes GameCube byte order in many resource structures.
   ARM is little-endian; swapping executable instructions alone is insufficient.
6. Memory requirements, rendering complexity and CPU load have not been profiled
   on either Old or New 3DS. No playable performance claim is justified yet.

An ARM compiler syntax probe of `src/sysGCU/graphics.cpp` was attempted with
`VERSION_GPVE01` and the repository's include paths. Linux first exposed an
upstream `JSYstem` capitalization error. A temporary external include alias
allowed the probe to continue; it still failed. The compiler log is saved as
`validation/arm-port-probe.log`. The uploaded source itself was not edited.
Failures include unavailable `__frsqrte` and `__fabsf` compiler intrinsics,
missing math declarations and C++ template constructs rejected by GCC.
These errors are additional porting work, not evidence that the entire game
can or cannot ultimately fit on 3DS.

## Next engineering gates

1. Run this small viewer on real hardware to establish basic RomFS and display
   behavior; test the extractor against a real supported disc image.
2. Implement bounded Yaz0/RARC extraction and J3D model/texture parsing. Render
   one actual game model or scene with Citro3D. Measure memory and frame time.
3. Build a platform layer for allocation, files, timing, input and threading;
   separate the original SDK and standard-library assumptions from portable C++.
4. Bring up game initialization and a controlled single scene; implement GX
   state translation and audio as required by that scene. Then expand gameplay.
5. Profile representative busy scenes on target hardware and address failures
   before calling the game playable or integrating a one-click full-game builder.

The supplied desktop builder establishes extraction and packaging only.
Finishing a faithful port requires sustained implementation and device testing;
no automatic full-game conversion method was discovered in this investigation.
